package com.example.librarymgmt;
import jakarta.persistence.*;
@Entity
public class Library {
	@Id
	private int bookid;
	private String title;
	private String author;
	private String category;
	private double price;
	private int availableCopies;
	
	public Library() {}
	
	public Library(int bookid,String title,String author,String category,double price,int availableCopies) {
		this.bookid=bookid;
		this.title=title;
		this.author=author;
		this.category=category;
		this.price=price;
		this.availableCopies=availableCopies;
	}
	
	public int getBookID() {
		return bookid;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getCategory() {
		return category;
	}
	
	public double getPrice() {
		return price;
	}
	
	public int getAvailableCopies() {
		return availableCopies;
	}
	
	public void setBookId(int bookid) {
	    this.bookid = bookid;
	}
	
	public void setTitle(String title) {
	    this.title=title;
	}
	
	public void setAuthor(String author) {
	    this.author=author;
	}
	
	public void setCategory(String category) {
	    this.category=category;
	}
	
	public void setPrice(double price) {
	    this.price=price;
	}
	
	public void setAvailableCopies(int availableCopies) {
	    this.availableCopies=availableCopies;
	}
	
	@Override
	public String toString() {
	    return "Library{" +
	            "bookId=" + bookid +
	            ", title='" + title + '\'' +
	            ", author='" + author + '\'' +
	            ", category='" + category + '\'' +
	            ", price=" + price +
	            ", availableCopies=" + availableCopies +
	            '}';
	}
	

}
