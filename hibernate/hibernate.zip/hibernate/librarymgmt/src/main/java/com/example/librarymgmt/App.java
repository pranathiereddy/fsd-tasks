package com.example.librarymgmt;

import java.util.*;

public class App 
{
	public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        LibraryDAO dao = new LibraryDAO();

        while (true) {

            System.out.println("\n===== LIBRARY MENU =====");
            System.out.println("1. Insert Book");
            System.out.println("2. Find Book By ID");
            System.out.println("3. Find All Books");
            System.out.println("4. Update Book");
            System.out.println("5. Delete Book");
            System.out.println("6. Exit");

            System.out.print("Enter Choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    Library l1 = new Library();

                    System.out.print("Enter Book Id: ");
                    l1.setBookId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Book Title: ");
                    l1.setTitle(sc.nextLine());
                    
                    System.out.print("Enter Book Author: ");
                    l1.setAuthor(sc.nextLine());
                    
                    System.out.print("Enter Book Category: ");
                    l1.setCategory(sc.nextLine());
                    
                    System.out.print("Enter Book Price: ");
                    l1.setPrice(sc.nextDouble());
                    
                    System.out.print("Enter Available Book Copies: ");
                    l1.setAvailableCopies(sc.nextInt());

                    dao.insert(l1);
                    System.out.println("Book Inserted Successfully");
                    break;

                case 2:
                    System.out.print("Enter Book Id: ");
                    int bid = sc.nextInt();

                    Library library = dao.findById(bid);

                    if (library != null) {
                        System.out.println(library);
                    } else {
                        System.out.println("Book Not Found");
                    }
                    break;

                case 3:
                    List<Library> books = dao.findAll();

                    for (Library b : books) {
                        System.out.println(b);
                    }
                    break;

                case 4:
                    Library l2 = new Library();
                    System.out.print("Enter Book Id: ");
                    l2.setBookId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter New Title: ");
                    l2.setTitle(sc.nextLine());
                    
                    System.out.print("Enter New Author: ");
                    l2.setAuthor(sc.nextLine());
                    
                    System.out.print("Enter New Category: ");
                    l2.setCategory(sc.nextLine());
                    
                    System.out.print("Enter New Price: ");
                    l2.setPrice(sc.nextDouble());
                    
                    System.out.print("Enter New Available Book Copies: ");
                    l2.setAvailableCopies(sc.nextInt());
                    dao.update(l2);
                    System.out.println("Book Updated Successfully");
                    break;

                case 5:
                    System.out.print("Enter Book Id: ");
                    int deleteId = sc.nextInt();

                    dao.delete(deleteId);
                    System.out.println("Book Deleted Successfully");
                    break;

                case 6:
                    System.out.println("Exiting Application...");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid Choice");
            }
        }
    }
}
