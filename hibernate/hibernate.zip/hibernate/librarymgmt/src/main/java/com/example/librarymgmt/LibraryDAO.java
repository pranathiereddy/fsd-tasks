package com.example.librarymgmt;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class LibraryDAO {


    private static SessionFactory factory =
            new Configuration().configure().buildSessionFactory();

    private Session getSession() {
        return factory.openSession();
    }

    // Insert
    public void insert(Library p) {
        Session session = getSession();
        Transaction tx = session.beginTransaction();

        session.persist(p);

        tx.commit();
        session.close();
    }

    // Find By Id
    public Library findById(int bookid) {
        Session session = getSession();

        Library library = session.find(Library.class, bookid);

        session.close();
        return library;
    }

    // Find All
    public List<Library> findAll() {
        Session session = getSession();

        List<Library> books = session
                .createQuery("from Library", Library.class)
                .list();

        session.close();
        return books;
    }

    // Update
    public void update(Library b) {
        Session session = getSession();
        Transaction tx = session.beginTransaction();

        session.merge(b);

        tx.commit();
        session.close();
    }

    // Delete
    public void delete(int bookid) {
        Session session = getSession();
        Transaction tx = session.beginTransaction();

        Library library= session.find(Library.class, bookid);
        if (library != null) {
            session.remove(library);
        }

        tx.commit();
        session.close();
    }
}
