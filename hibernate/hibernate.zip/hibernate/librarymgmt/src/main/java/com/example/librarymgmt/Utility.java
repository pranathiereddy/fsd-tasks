package com.example.librarymgmt;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class Utility {
	private static final SessionFactory sessionFactory=
			new Configuration()
			.configure()
			.addAnnotatedClass(Library.class)
			.buildSessionFactory();
	
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	
	public static void shutdown() {
		sessionFactory.close();
	}

}